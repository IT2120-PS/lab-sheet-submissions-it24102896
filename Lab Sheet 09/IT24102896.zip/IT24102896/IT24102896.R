setwd("C:\\Users\\Mirahi\\Desktop\\IT24102896")

set.seed(123) 
baking_time <- rnorm(25, mean = 45, sd = 2)

t_test_result <- t.test(baking_time, mu = 46, alternative = "less")

print(t_test_result)

t_test_result$statistic     
t_test_result$p.value     
t_test_result$conf.int      
