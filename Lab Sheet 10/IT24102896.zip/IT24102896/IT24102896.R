setwd("C:\\Users\\Mirahi\\Desktop\\IT24102896")

observed <- c(120, 95, 85, 100)
total <- sum(observed)
expected <- rep(total / length(observed), length(observed))
chisq.test(observed, p = expected / total)
